# -*- coding: utf-8 -*-

from . import request_inventory